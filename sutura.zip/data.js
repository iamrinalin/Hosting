/* ============ SHARED DATA + COMPONENTS ============
   Used by both index.html (Dashboard) and garments.html (Browse)
*/

const GARMENTS = [
  { cat:"Formal Gown", tone:["#efe6d3","#cbb68c","#a4855a"], icon:"gown", price:12500, days:20, title:"Premium Piña Filipiniana", shop:"Dela Cruz Tailoring", rating:4.8, reviews:5, city:"Davao City", verified:true },
  { cat:"Barong Tagalog", tone:["#f1ece0","#d9cba4","#b79a67"], icon:"gown", price:8500, days:15, title:"Modern Terno", shop:"Dela Cruz Tailoring", rating:4.9, reviews:5, city:"Davao City", verified:true },
  { cat:"Barong Tagalog", tone:["#3b4a63","#28324a","#1b2233"], icon:"gown", price:45000, days:60, title:"Bespoke Wedding Gown", shop:"Flores Bridal & Formal", rating:4.6, reviews:9, city:"Davao City", verified:true },
  { cat:"Formal Gown", tone:["#f7f2e6","#e6dcc0","#cbb888"], icon:"gownfull", price:4500, days:21, title:"Bridesmaid Dress", shop:"Flores Bridal & Formal", rating:4.6, reviews:7, city:"Davao City", verified:false },
  { cat:"Barong Tagalog", tone:["#efeadf","#d8cdb0","#b7a374"], icon:"shirt", price:8000, days:14, title:"Classic Piña Barong", shop:"Santos Stitch & Style", rating:4.6, reviews:6, city:"Davao City", verified:false },
  { cat:"Barong Tagalog", tone:["#f2ede2","#ddd0ac","#c0aa76"], icon:"shirt", price:2200, days:7, title:"Jusi Office Barong", shop:"Santos Stitch & Style", rating:4.4, reviews:8, city:"Davao City", verified:false },
  { cat:"School Uniform", tone:["#f1ece0","#d9cba4","#b79a67"], icon:"shirt", price:1200, days:5, title:"Standard PE Uniform Set", shop:"Reyes Custom Tailors", rating:4.3, reviews:12, city:"Davao City", verified:true },
  { cat:"Office Polo", tone:["#efeadf","#d8cdb0","#b7a374"], icon:"shirt", price:1800, days:6, title:"Tailored Office Polo", shop:"Reyes Custom Tailors", rating:4.5, reviews:10, city:"Davao City", verified:false },
  { cat:"Formal Suit", tone:["#3b4a63","#28324a","#1b2233"], icon:"gown", price:9800, days:18, title:"Barako Grey Two-Piece Suit", shop:"Ocampo Menswear", rating:4.7, reviews:14, city:"Davao City", verified:true },
  { cat:"Casual Wear", tone:["#f7f2e6","#e6dcc0","#cbb888"], icon:"shirt", price:1500, days:4, title:"Linen Casual Set", shop:"Ocampo Menswear", rating:4.2, reviews:9, city:"Davao City", verified:false },
  { cat:"Alterations", tone:["#f2ede2","#ddd0ac","#c0aa76"], icon:"shirt", price:600, days:3, title:"Gown Fitting & Alteration", shop:"Santos Stitch & Style", rating:4.5, reviews:20, city:"Davao City", verified:false },
  { cat:"Custom Dress", tone:["#efe6d3","#cbb68c","#a4855a"], icon:"gownfull", price:6500, days:12, title:"Rustic Garden Wedding Dress", shop:"Flores Bridal & Formal", rating:4.7, reviews:6, city:"Davao City", verified:true },
  { cat:"Wedding Dress", tone:["#f7f2e6","#e6dcc0","#cbb888"], icon:"gownfull", price:38000, days:45, title:"Classic Ball Gown Wedding Dress", shop:"Dela Cruz Tailoring", rating:4.9, reviews:11, city:"Davao City", verified:true },
];
GARMENTS.forEach((g,i)=> g._id = i);

const CATEGORIES = [
  { name:"Filipiniana", icon:"👗" },
  { name:"Barong Tagalog", icon:"👔" },
  { name:"Formal Suit", icon:"🤵" },
  { name:"Formal Gown", icon:"👗" },
  { name:"Wedding Dress", icon:"💍" },
  { name:"School Uniform", icon:"🎓" },
  { name:"Office Polo", icon:"👕" },
  { name:"Alterations", icon:"✂️" },
  { name:"Casual Wear", icon:"👚" },
  { name:"Custom Dress", icon:"🧵" },
];

const SHOPS = [
  { name:"Dela Cruz Tailoring", spec:"Filipiniana & Terno specialist", rating:4.8, reviews:34, verified:true },
  { name:"Flores Bridal & Formal", spec:"Wedding gowns & bridal wear", rating:4.6, reviews:41, verified:true },
  { name:"Santos Stitch & Style", spec:"Barong & office wear", rating:4.5, reviews:26, verified:false },
];

const ICONS = {
  gown: `<circle cx="150" cy="60" r="18" fill="rgba(0,0,0,0.12)"/><path d="M110 80 Q150 70 190 80 L200 220 Q150 240 100 220 Z" fill="rgba(255,255,255,0.35)"/><line x1="70" y1="60" x2="70" y2="240" stroke="rgba(0,0,0,0.15)" stroke-width="3"/><line x1="230" y1="60" x2="230" y2="240" stroke="rgba(0,0,0,0.15)" stroke-width="3"/>`,
  gownfull: `<circle cx="150" cy="55" r="16" fill="rgba(0,0,0,0.12)"/><path d="M125 72 L175 72 L185 130 Q220 220 150 250 Q80 220 115 130 Z" fill="rgba(255,255,255,0.4)"/>`,
  shirt: `<path d="M110 70 L130 55 L150 70 L170 55 L190 70 L180 100 L165 92 L165 220 L135 220 L135 92 L120 100 Z" fill="rgba(255,255,255,0.4)"/>`
};

function peso(n){ return "\u20b1" + n.toLocaleString("en-PH"); }

function thumbSvg(g){
  return `<svg viewBox="0 0 300 235" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="g${g._id}" x1="0" y1="0" x2="0.6" y2="1">
        <stop offset="0%" stop-color="${g.tone[0]}"/>
        <stop offset="60%" stop-color="${g.tone[1]}"/>
        <stop offset="100%" stop-color="${g.tone[2]}"/>
      </linearGradient>
    </defs>
    <rect width="300" height="235" fill="url(#g${g._id})"/>
    <g opacity="0.9">${ICONS[g.icon]}</g>
  </svg>`;
}

/* Garment card component — renders one card's HTML (display-only, no product-detail page exists) */
function garmentCard(g){
  return `
    <div class="card">
      <div class="thumb">
        ${thumbSvg(g)}
        <div class="price-tag">
          <div class="price"><small>SET PRICE</small>${peso(g.price)}</div>
          <div class="days">${g.days} days</div>
        </div>
      </div>
      <div class="card-body">
        <div class="card-cat">${g.cat}</div>
        <h3 class="card-title">${g.title}</h3>
        <div class="shop-row">
          <div class="shop-avatar"></div>
          <div class="shop-info">
            <div class="shop-name">${g.shop} ${g.verified ? '<span class="verified">✔</span>' : ''}</div>
            <div class="meta-row"><span class="star">★</span> ${g.rating} · ${g.reviews} ${g.city}</div>
          </div>
        </div>
      </div>
    </div>
  `;
}

/* Mobile top nav + burger — shared behavior */
function initHeader(){
  const burgerBtn = document.getElementById("burgerBtn");
  const mobileMenu = document.getElementById("mobileMenu");
  if(burgerBtn && mobileMenu){
    burgerBtn.addEventListener("click", () => mobileMenu.classList.toggle("open"));
  }
}

/* ============ ORDERS ============ */
const ORDERS = [
  { id:"ORD-001", status:"stitching", title:"Filipiniana Dress", shop:"Dela Cruz Tailoring", branch:"Main Branch", amount:2500, placed:"May 1", eta:"May 15, 2025", progress:60 },
  { id:"ORD-011", status:"completed", title:"Barong Tagalog", shop:"Santos Stitch & Style", branch:"IT Park Branch", amount:1800, placed:"Mar 1", eta:"March 11, 2025", progress:100 },
];

function statusLabel(s){
  return { stitching:"Stitching", completed:"Completed", pending:"Pending", cancelled:"Cancelled" }[s] || s;
}

function orderCard(o){
  return `
    <div class="order-card ${o.status}">
      <div class="order-top">
        <div>
          <div class="order-id">ORDER #${o.id} <span class="status-badge ${o.status}">${statusLabel(o.status)}</span></div>
          <div class="order-title">${o.title}</div>
          <div class="order-shop">🏠 ${o.shop} · ${o.branch}</div>
        </div>
        <div class="order-amount">
          <div class="label">Total Amount</div>
          <div class="amt">${peso(o.amount)}</div>
          <div class="placed">Placed ${o.placed}</div>
        </div>
      </div>
      <div class="order-progress">
        <div class="order-progress-top"><span>Status Progress</span><span class="val">${statusLabel(o.status)}</span></div>
        <div class="progress-track"><div class="progress-fill" style="width:${o.progress}%"></div></div>
      </div>
      <div class="order-bottom">
        <span>📅 Est. Completion: ${o.eta}</span>
        <a href="#">View Details ›</a>
      </div>
    </div>
  `;
}

/* ============ NOTIFICATIONS ============ */
const NOTIFICATIONS = [
  { icon:"📦", unread:true, title:"Order Update", time:"May 20, 9:30 AM", desc:'Your Filipiniana dress (ORD-001) is now being stitched.', link:true },
  { icon:"📦", unread:false, title:"Ready for Pickup", time:"May 15, 2:00 PM", desc:'Your Barong Tagalog (ORD-011) is ready. Visit Santos Stitch at IT Park branch.', link:true },
  { icon:"📣", unread:true, title:"Shop Announcement", time:"May 18, 10:00 AM", desc:'Dela Cruz Tailoring is offering 10% off all alterations this May.', link:false },
  { icon:"📦", unread:false, title:"Order Accepted", time:"May 11, 8:15 AM", desc:'Your Formal Gown (ORD-005) has been accepted by Dela Cruz Tailoring.', link:true },
];

function notifItem(n){
  return `
    <div class="notif-item">
      <div class="notif-icon">${n.icon}</div>
      <div class="notif-body">
        <div class="notif-top">
          <div class="notif-title">${n.unread ? '<span class="notif-dot"></span>' : ''}${n.title}</div>
          <div class="notif-time">${n.time}</div>
        </div>
        <div class="notif-desc">${n.desc}</div>
        ${n.link ? '<a class="btn" href="#">View Order Details ›</a>' : ''}
      </div>
    </div>
  `;
}

/* ============ SAVED SHOPS (detailed, for Saved Shops page) ============ */
const SAVED_SHOPS = [
  { name:"Dela Cruz Tailoring", tier:"Premium", rating:4.8, reviews:142, tags:["Filipiniana","Formal Gown","Alterations"], city:"Davao City", branches:2, tone:["#e9d9b8","#b98f57"] },
  { name:"Santos Stitch & Style", tier:"Pro", rating:4.5, reviews:98, tags:["Barong Tagalog","School Uniform","Office Polo"], city:"Davao City", branches:2, tone:["#d7cdbd","#8c7a5e"] },
  { name:"Flores Bridal & Formal", tier:"Premium", rating:4.9, reviews:201, tags:["Wedding Dress","Formal Gown","Filipiniana"], city:"Davao City", branches:1, tone:["#26324a","#3b4a63"] },
  { name:"Lim Tailoring House", tier:"Premium", rating:4.7, reviews:115, tags:["Barong Tagalog","Formal Suit","Custom Dress"], city:"Davao City", branches:2, tone:["#6b5334","#8f7248"] },
];

function savedShopCard(s){
  return `
    <div class="saved-card">
      <div class="saved-cover" style="background:linear-gradient(140deg, ${s.tone[0]}, ${s.tone[1]})">
        <span class="tier-badge">${s.tier}</span>
        <button class="bookmark-btn" aria-label="Bookmarked">🔖</button>
      </div>
      <div class="saved-body">
        <div class="saved-name">${s.name}</div>
        <div class="saved-rating"><span class="star">★</span> ${s.rating} (${s.reviews} reviews)</div>
        <div class="saved-tags">${s.tags.map(t=>`<span class="saved-tag">${t.toUpperCase()}</span>`).join("")}</div>
        <div class="saved-loc">📍 ${s.city} · ${s.branches} branch${s.branches===1?'':'es'}</div>
        <div class="saved-btns">
          <button class="btn">View Shop</button>
          <button class="btn">Place Order</button>
        </div>
      </div>
    </div>
  `;
}

/* ============ MEASUREMENTS ============ */
const MEASUREMENTS = [
  { name:"Filipiniana measurements", tag:"FILIPINIANA", pct:58, date:"May 1, 2025",
    fields:[ {v:"86",l:"Bust"}, {v:"38",l:"Shoulder Width"}, {v:"68",l:"Waist"}, {v:"92",l:"Hips"}, {v:"58",l:"Sleeve Length"}, {v:"42",l:"Back Length"} ],
    note:"Prefers fitted silhouette" },
  { name:"Gown measurements", tag:"FORMAL GOWN", pct:42, date:"Jan 10, 2025",
    fields:[ {v:"85",l:"Bust"}, {v:"38",l:"Shoulder Width"}, {v:"67",l:"Waist"}, {v:"91",l:"Hips"}, {v:"42",l:"Back Length"}, {v:null,l:"Empty"} ],
    note:null },
];

function measureCard(m){
  return `
    <div class="measure-card">
      <div class="measure-head">
        <div class="measure-title-row">
          <div class="measure-icon">📐</div>
          <div>
            <div class="measure-name">${m.name}</div>
            <span class="measure-tag">${m.tag}</span>
          </div>
        </div>
        <span class="measure-pct">${m.pct}%</span>
      </div>
      <div class="progress-track"><div class="progress-fill" style="width:${m.pct}%"></div></div>
      <div class="measure-fields">
        ${m.fields.map(f => `
          <div class="measure-field">
            <div class="val ${f.v ? '' : 'empty'}">${f.v ? f.v : '—'}</div>
            <div class="lbl">${f.l}</div>
          </div>
        `).join("")}
      </div>
      <div class="measure-foot">
        <span>📅 ${m.date}</span>
        <a href="#">View All ›</a>
      </div>
      ${m.note ? `<div class="measure-note">🚩 ${m.note}</div>` : ''}
    </div>
  `;
}
